/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   identify.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: raveriss <raveriss@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 14:42:24 by raveriss          #+#    #+#             */
/*   Updated: 2024/05/29 15:55:32 by raveriss         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* Inclusion de la librairie standard */
#include <iostream>

/* Inclusion de la classe Base */
#include "../incs/Base.hpp"

/* Inclusion des classes A, B et C */
#include "../incs/A.hpp"
#include "../incs/B.hpp"
#include "../incs/C.hpp"

/**
 * @brief Identifie le type réel de l'objet pointé par Base* ou Base* (A, B ou C)
 */
void identify(Base* p)
{
    if (p == NULL)
    {
        std::cout << "Invalid pointer" << std::endl;
        return;
    }
    
    if (dynamic_cast<A*>(p))
        std::cout << "A" << std::endl;
    else if (dynamic_cast<B*>(p))
        std::cout << "B" << std::endl;
    else if (dynamic_cast<C*>(p))
        std::cout << "C" << std::endl;
}

/**
  @brief Identifie le type réel de l'objet référencé par Base& (A, B ou C)
 */
void identify(Base& p) {
    // Convert the reference to a pointer for null-checking
    Base* pCheck = &p;
    if (pCheck == NULL) {
        std::cout << "Invalid reference" << std::endl;
        return;
    }

    if (dynamic_cast<A*>(pCheck))
        std::cout << "A" << std::endl;
    else if (dynamic_cast<B*>(pCheck))
        std::cout << "B" << std::endl;
    else if (dynamic_cast<C*>(pCheck))
        std::cout << "C" << std::endl;
    else
        std::cout << "Invalid reference" << std::endl;
}



