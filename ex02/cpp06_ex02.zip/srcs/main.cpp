/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: raveriss <raveriss@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 14:43:12 by raveriss          #+#    #+#             */
/*   Updated: 2024/05/28 14:57:45 by raveriss         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Base.hpp"
#include "A.hpp"
#include "B.hpp"
#include "C.hpp"
#include "../incs/identify.hpp"
#include "../incs/generate.hpp"

int main()
{
    Base* p = generate();
    identify(p);
    identify(*p);
    delete p;
    return 0;
}
